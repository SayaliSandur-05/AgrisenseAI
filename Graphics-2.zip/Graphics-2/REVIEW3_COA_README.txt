AGRISENSE AI - REVIEW 3 INTEGRATED COA UPDATE
============================================

This update preserves the supplied Graphics application and the existing OOPS
stack/history files. The Review 3 COA additions are integrated into the Alerts
screen of the existing zone dashboard.

WHAT IS INCLUDED
----------------
1. CO.1 / CO.2: Existing real x86-64 NASM threshold checks for soil moisture
   and temperature remain in threshold.asm and are called from COA.h / Zone.h.
2. CO.3: asm_mul_add_shift performs unsigned binary add-and-shift multiplication.
   The Alerts screen demonstrates 20 square metres x 5 mm = 100 litres.
   (1 mm of water over 1 m2 is 1 litre.)
3. Review 3 string operations: asm_string_length counts a null-terminated crop
   name; asm_string_equal performs exact case-sensitive string comparison.
   The Alerts screen displays the selected crop's length and whether it exactly
   matches the lowercase string "rice".
4. CO.4: The existing COA instruction trace remains visible in the Alerts view.
   It is an educational trace of the threshold decision, not a physical view of
   the CPU's internal pipeline.
5. OOPS / Stack additions from the supplied archive are retained:
   CropLifeHistoryStack.h, OOPSUtilities.h and the existing history UI.

WHERE TO SEE THE OUTPUT
-----------------------
Run the existing AgriSense AI OpenGL application. Select a zone, open its
Dashboard menu, then open "Alerts". Below the existing COA Assembly Instruction
Trace, the new section "Review 3: Assembly Algorithm & String Operations"
shows the irrigation multiplication result and the two string-operation results.

BUILD ON WINDOWS (32/64-bit consistency is essential)
------------------------------------------------------
The supplied threshold.asm explicitly uses the Windows x64 calling convention.
Build the application as 64-bit and use NASM's win64 object format.

1. Open PowerShell in this Graphics folder.
2. Assemble the updated NASM source:
       nasm -f win64 threshold.asm -o threshold.obj
3. Rebuild test.cpp using the SAME GLUT/freeglut include paths and libraries
   that were used for the existing working application, and include threshold.obj
   in the link command. For a typical MinGW-w64/freeglut setup the command is:
       g++ -std=c++17 -O2 test.cpp threshold.obj -o agrisense_review3.exe -lfreeglut -lopengl32 -lglu32 -lwinmm -lgdi32
   If your installation uses a different GLUT library name or include path,
   retain your existing project's known-good flags and add threshold.obj.
4. Run:
       .\agrisense_review3.exe

IMPORTANT TESTS
---------------
- Check that NASM is available: nasm -v
- Ensure the C++ compiler target is x86_64-w64-mingw32 (not 32-bit MinGW).
- Test irrigation output: 20 x 5 must show 100 litres.
- Test string length: crop name "rice" must show 4.
- Test exact comparison: lowercase "rice" must show YES; "Rice" shows NO
  because the operation is case-sensitive.
- Test existing soil-moisture and temperature alerts still work.

LIMITATIONS / ACCURACY
----------------------
- The add-and-shift routine is unsigned 32-bit arithmetic; overflow wraps modulo
  2^32. The demonstration uses small positive values.
- The string comparison is case-sensitive and expects valid null-terminated
  strings. Crop names entered through the UI are null-terminated char buffers.
- The irrigation example is an estimate based on area and irrigation depth; it
  is not an automatic pump controller and does not measure actual water flow.
- The displayed COA trace is a teaching trace. It must not be described as a
  measured five-stage hardware pipeline of the host processor.
- This source archive was updated but not compiled on the user's Windows/GLUT
  installation in this environment. Build and run the steps above before demo.
