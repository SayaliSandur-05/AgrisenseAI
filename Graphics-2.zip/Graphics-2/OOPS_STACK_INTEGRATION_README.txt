AgriSenseAI - OOPS + Stack integration update

Files added:
- CropLifeHistoryStack.h : std::stack-based crop event history (LIFO), plus a chronological list for display.
- OOPSUtilities.h : reusable template clampValue<T>() and percentage validation with exceptions.

File updated:
- test.cpp : adds a Crop Life History screen to the existing Recent Zone History menu card. It has buttons to add Sowing, Watering, Fertilizer, Growth, and Harvest events. Events are stored per zone and shown newest-first. Saving a crop also records a sowing/save event.

Existing files retained:
- sensor.h, Zone.h, ZoneHistory.h, DataStructures.h, COA files and existing dashboard assets remain in place.

Important:
- The UI uses "Current session" as the date label; this is not an actual timestamp. Replace with real date/time capture if required by your rubric.
- The stack is in-memory and resets when the program closes; persistent file storage is not implemented.
- OOPSUtilities.h supplies the template/exception utilities, but validatePercentage() is not yet wired to the sensor +/- controls. Do not claim it validates every dashboard reading until you integrate it there.
- Build in your existing Windows environment with the same GLUT/OpenGL settings you use for the original test.cpp. This archive has not been compiled in that Windows environment here; please build and test before submission.
