// =============================================================================
// threshold_asm.h  --  C++ declarations for the real assembly functions
// -----------------------------------------------------------------------------
// The implementations live in threshold.asm and are linked in at build time.
// =============================================================================
#ifndef THRESHOLD_ASM_H
#define THRESHOLD_ASM_H

extern "C" {

// Returns: 0 = OK, 1 = WARNING, 2 = DANGER
int asm_soil_moisture_check(int value, int minVal, int maxVal);

// Returns: 0 = OK, 2 = DANGER
int asm_temperature_check(int value, int minVal, int maxVal);

// CO.3: unsigned binary add-and-shift multiplication.
unsigned int asm_mul_add_shift(unsigned int multiplicand, unsigned int multiplier);

// Review 3 string operations: length and exact case-sensitive comparison.
unsigned int asm_string_length(const char* text);
int asm_string_equal(const char* left, const char* right);

}

#endif // THRESHOLD_ASM_H