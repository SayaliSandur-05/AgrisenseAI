; =============================================================================
; threshold.asm  --  AgriSense AI  --  Real x86-64 assembly (Windows win64 ABI)
; =============================================================================
; Assemble:  nasm -f win64 threshold.asm -o threshold.obj
; Verify:    objdump -d threshold.obj
;
; Windows x64 calling convention:
;   arg1 -> ecx,  arg2 -> edx,  arg3 -> r8d
;   return value -> eax
; =============================================================================

section .text

; -----------------------------------------------------------------------------
; int asm_soil_moisture_check(int value, int min, int max)
;   Returns: 0 = OK, 1 = WARNING (value > max), 2 = DANGER (value < min)
; -----------------------------------------------------------------------------
global asm_soil_moisture_check

asm_soil_moisture_check:
    mov     eax, ecx            ; eax = value  (arg1)
    mov     r9d, edx            ; r9d = min    (arg2)
    cmp     eax, r9d
    jge     .check_max

    mov     eax, 2              ; value < min -> DANGER
    ret

.check_max:
    mov     r9d, r8d            ; r9d = max    (arg3)
    cmp     eax, r9d
    jle     .ok

    mov     eax, 1              ; value > max -> WARNING
    ret

.ok:
    xor     eax, eax            ; return 0
    ret

; -----------------------------------------------------------------------------
; int asm_temperature_check(int value, int min, int max)
;   Returns: 0 = OK, 2 = DANGER
; -----------------------------------------------------------------------------
global asm_temperature_check

asm_temperature_check:
    mov     eax, ecx            ; value
    mov     r9d, edx            ; min
    cmp     eax, r9d
    jl      .danger

    mov     r9d, r8d            ; max
    cmp     eax, r9d
    jg      .danger

    xor     eax, eax
    ret

.danger:
    mov     eax, 2
    ret

; -----------------------------------------------------------------------------
; unsigned int asm_mul_add_shift(unsigned int multiplicand, unsigned int multiplier)
; Win64: ECX=multiplicand, EDX=multiplier, result EAX.
; Binary add-and-shift multiplication (unsigned 32-bit; result wraps at 32 bits).
; -----------------------------------------------------------------------------
global asm_mul_add_shift
asm_mul_add_shift:
    xor     eax, eax            ; product = 0
    mov     r8d, ecx            ; shifted multiplicand
    mov     r9d, edx            ; shifting multiplier
.mul_loop:
    test    r9d, 1
    jz      .skip_add
    add     eax, r8d            ; add when current multiplier bit is 1
.skip_add:
    shl     r8d, 1              ; multiplicand *= 2
    shr     r9d, 1              ; multiplier /= 2
    jnz     .mul_loop
    ret

; -----------------------------------------------------------------------------
; unsigned int asm_string_length(const char* text) -- RCX pointer, EAX length
; -----------------------------------------------------------------------------
global asm_string_length
asm_string_length:
    xor     eax, eax
.len_loop:
    cmp     byte [rcx + rax], 0
    je      .len_done
    inc     eax
    jmp     .len_loop
.len_done:
    ret

; -----------------------------------------------------------------------------
; int asm_string_equal(const char* left, const char* right)
; Win64: RCX=left, RDX=right; EAX=1 equal, EAX=0 different.
; -----------------------------------------------------------------------------
global asm_string_equal
asm_string_equal:
.str_loop:
    mov     al, [rcx]
    mov     r8b, [rdx]
    cmp     al, r8b
    jne     .str_not_equal
    test    al, al
    je      .str_equal
    inc     rcx
    inc     rdx
    jmp     .str_loop
.str_equal:
    mov     eax, 1
    ret
.str_not_equal:
    xor     eax, eax
    ret
