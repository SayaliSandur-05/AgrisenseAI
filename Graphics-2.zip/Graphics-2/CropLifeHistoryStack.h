#ifndef CROP_LIFE_HISTORY_STACK_H
#define CROP_LIFE_HISTORY_STACK_H

#include <stack>
#include <string>
#include <vector>
#include <stdexcept>

struct CropLifeEvent {
    std::string date;
    std::string type;
    std::string details;
    CropLifeEvent() {}
    CropLifeEvent(const std::string& d, const std::string& t, const std::string& info)
        : date(d), type(t), details(info) {}
};

// PL topic: LIFO stack. Events are kept newest-first for quick access.
class CropLifeHistoryStack {
private:
    std::stack<CropLifeEvent> events;
    std::vector<CropLifeEvent> chronological;
public:
    void push(const CropLifeEvent& event) {
        events.push(event);
        chronological.push_back(event);
    }
    bool empty() const { return events.empty(); }
    std::size_t size() const { return events.size(); }
    const CropLifeEvent& top() const {
        if (events.empty()) throw std::runtime_error("No crop history records yet.");
        return events.top();
    }
    CropLifeEvent pop() {
        if (events.empty()) throw std::runtime_error("No crop history record to remove.");
        CropLifeEvent e = events.top(); events.pop();
        if (!chronological.empty()) chronological.pop_back();
        return e;
    }
    const std::vector<CropLifeEvent>& allChronological() const { return chronological; }
};
#endif
