#ifndef OOPS_UTILITIES_H
#define OOPS_UTILITIES_H
#include <stdexcept>
#include <string>
#include <sstream>

// OOPS/templates: reusable numeric range helper.
template <typename T>
T clampValue(T value, T minimum, T maximum) {
    if (minimum > maximum) throw std::invalid_argument("Minimum cannot exceed maximum.");
    if (value < minimum) return minimum;
    if (value > maximum) return maximum;
    return value;
}

// OOPS/templates + exception handling: validate percentage sensor readings.
inline float validatePercentage(float value, const std::string& sensorName) {
    if (value < 0.0f || value > 100.0f)
        throw std::out_of_range(sensorName + " must be between 0 and 100.");
    return value;
}
#endif
